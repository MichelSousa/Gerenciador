insert into permissao (per_nome,per_descricao,per_dtinclusao) values ('Administrador','Usuario dono do plano',now());
insert into permissao (per_nome,per_descricao,per_dtinclusao) values ('Usuario','Usuario subordinado',now());
insert into permissao (per_nome,per_descricao,per_dtinclusao) values ('Admin','Administrador do sistema',now());

insert into plano (pla_nome,pla_descricao,pla_valor) values ('Livre','3 usu�rios, 5 projetos',0);
insert into plano (pla_nome,pla_descricao,pla_valor) values ('Plano 1','Usu�rio ilimitado, 30 projetos',10.90);
insert into plano (pla_nome,pla_descricao,pla_valor) values ('Plano 2','Usu�rio ilimitado, 100 projetos',29.90);
insert into plano (pla_nome,pla_descricao,pla_valor) values ('Plano 3','Usu�rio ilimitado, projeto ilimitado',39.90);

-- Retorna usuario e sua permissao
select usu_nome, per_nome
  from usuario
  join permissaousuario
    on pes_usu_cod = usu_cod
  join permissao
    on pes_per_cod = per_cod
 where usu_cod = 2;
